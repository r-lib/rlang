#ifndef RLANG_DEBUG_H
#define RLANG_DEBUG_H


#define r_printf Rprintf
void r_sexp_inspect(sexp* x, sexp* env);


#endif
